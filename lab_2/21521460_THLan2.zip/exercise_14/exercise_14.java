public class exercise_14 {
    public static void main(String[] args) {
        
    }
}
