public class exercise_12 {
    public static void main(String[] args) {
        
    }
}
