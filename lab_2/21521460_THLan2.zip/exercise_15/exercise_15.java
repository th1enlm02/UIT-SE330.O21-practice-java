public class exercise_15 {
    public static void main(String[] args) {
        
    }
}
